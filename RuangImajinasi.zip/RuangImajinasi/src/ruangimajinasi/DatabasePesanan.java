//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//Class Controller Pemesanan

package ruangimajinasi;

import java.sql.*;
import javax.swing.*;

public class DatabasePesanan {
    int totalHarga;
    DataPesanan dataPesanan = new DataPesanan();
    String DBurl = "jdbc:mysql://localhost/ruang_imajinasi";
    String DBuser = "root";
    String DBpass = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultSet;
    
    public void MasukDatabasePesanan(DataPesanan dataPesanan) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            statement.executeUpdate("insert into pesanan values ('" + dataPesanan.getPesanan()+ "','" + dataPesanan.getHarga()
                    + "','" + dataPesanan.getGelas()+ "','" + dataPesanan.getGula() + "','" + dataPesanan.getCatatan()+ "')");
            JOptionPane.showMessageDialog(null, "Pesanan segera diantar!!");
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            System.out.println("SQL exception error = " + ex);
            JOptionPane.showMessageDialog(null, "Pesanan gagal!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
            System.out.println("Class Not Found Exception error = " + ex); 
        }
    }
    
    public void CetakNota(String[][] data){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            String sql = "select * from pesanan";
            resultSet = statement.executeQuery(sql);
            int p = 0;
            while (resultSet.next()) {
                data[p][0] = resultSet.getString("nama");
                data[p][1] = resultSet.getString("harga");
                p++;
            }
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Data gagal ditemukan!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
        }
    }
    
    public void HapusDataPesanan(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            String sql = "delete from pesanan";
            statement.executeUpdate(sql);
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Data gagal ditemukan!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
        }
    }

    void TotalHarga() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            String sql = "select * from pesanan";
            resultSet = statement.executeQuery(sql);
            int p = 0;
            while (resultSet.next()) {
                totalHarga = resultSet.getInt("harga");
                dataPesanan.setTotalHagra(totalHarga);
                p++;
            }
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Data gagal ditemukan!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
        }
    }
    
    public int bayar(){
        return dataPesanan.getTotalHarga();
    }
}
