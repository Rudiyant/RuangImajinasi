//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//View SignUp

package ruangimajinasi;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ViewSignUp extends JFrame {
    JTextField fnama, fnoHp, fuser, fpass;
    JLabel lnama, lnoHp, luser, lpass, ldaftarmember, lruang, lbg;
    JButton btnSignup, btnLogin;

    DataMember dataMember = new DataMember();
    DatabaseMember dbM = new DatabaseMember();

    public ViewSignUp() {
        setTitle("Sign Up");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(300, 485);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);

        lruang = new JLabel();
        add(lruang).setBounds(30, 10, 405, 200);
        lruang.setIcon(new ImageIcon("src/Image/2.png"));

        ldaftarmember = new JLabel("Daftar Member");
        add(ldaftarmember).setBounds(100, 220, 120, 20);
        ldaftarmember.setFont(new Font("Gadugi", 1, 12));
        ldaftarmember.setForeground(Color.white);

        lnama = new JLabel("Nama");
        add(lnama).setBounds(20, 250, 100, 20);
        lnama.setFont(new Font("Gadugi", 1, 11));
        lnama.setForeground(Color.white);

        fnama = new JTextField(30);
        add(fnama).setBounds(140, 250, 120, 20);
        fnama.setForeground(Color.white);

        lnoHp = new JLabel("No HP");
        add(lnoHp).setBounds(20, 275, 100, 20);
        lnoHp.setFont(new Font("Gadugi", 1, 11));
        lnoHp.setForeground(Color.white);

        fnoHp = new JTextField(15);
        add(fnoHp).setBounds(140, 275, 120, 20);
        fnoHp.setForeground(Color.white);

        luser = new JLabel("Username");
        add(luser).setBounds(20, 300, 100, 20);
        luser.setFont(new Font("Gadugi", 1, 11));
        luser.setForeground(Color.white);

        fuser = new JTextField(10);
        add(fuser).setBounds(140, 300, 120, 20);
        fuser.setForeground(Color.white);

        lpass = new JLabel("Passworde");
        add(lpass).setBounds(20, 325, 100, 20);
        lpass.setFont(new Font("Gadugi", 1, 11));
        lpass.setForeground(Color.white);

        fpass = new JTextField(10);
        add(fpass).setBounds(140, 325, 120, 20);
        fpass.setForeground(Color.white);

        btnSignup = new JButton("SignUp");
        add(btnSignup).setBounds(90, 365, 100, 20);
        btnSignup.setBackground(Color.white);
        btnSignup.setForeground(Color.black);

        btnLogin = new JButton("Login");
        add(btnLogin).setBounds(90, 405, 100, 20);
        btnLogin.setBackground(Color.white);
        btnLogin.setForeground(Color.black);

        fnama.setBackground(Color.black);
        fnoHp.setBackground(Color.black);
        fuser.setBackground(Color.black);
        fpass.setBackground(Color.black);

        lbg = new JLabel();
        add(lbg).setBounds(0, 0, 300, 485);
        lbg.setIcon(new ImageIcon("src/Image/HITAM.jpg"));

        btnSignup.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nama, noHp, user, pass;
                nama = fnama.getText();
                dataMember.setNama(nama);
                noHp = fnoHp.getText();
                dataMember.setNoHp(noHp);
                user = fuser.getText();
                dataMember.setUser(user);
                pass = fpass.getText();
                dataMember.setPass(pass);

                dbM.MasukDatabase(dataMember);
            }
        });

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewLogin();
                dispose();
            }
        });
    }
}
