//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//Class Model Member

package ruangimajinasi;

public class DataMember {
    private String nama, noHp, user, pass;
    private static String wellcomeName;

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNoHp() {
        return noHp;
    }

    public void setNoHp(String noHp) {
        this.noHp = noHp;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
    
    public String getWellcomeName() { return wellcomeName; }

    public void setWellcomeName(String wellcomeName) { this.wellcomeName = wellcomeName; }
}
