//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//Class Controller Member

package ruangimajinasi;

import java.sql.*;
import javax.swing.*;

public class DatabaseMember {
    String DBurl = "jdbc:mysql://localhost/ruang_imajinasi";
    String DBuser = "root";
    String DBpass = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultSet;
    
    public void MasukDatabase(DataMember dataMember) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            statement.executeUpdate("insert into datamember values ('" + dataMember.getNama() + "','" + dataMember.getNoHp()
                    + "','" + dataMember.getUser() + "','" + dataMember.getPass() + "')");
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan!!");
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            System.out.println("SQL exception error = " + ex);
            JOptionPane.showMessageDialog(null, "Data gagal disimpan!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
            System.out.println("Class Not Found Exception error = " + ex);
            
        }
    }
    
        public void LoginMember(DataMember dataMember){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            String sql = "SELECT * FROM `datamember` WHERE `user`='" + dataMember.getUser() + "'AND `pass`='" + dataMember.getPass() + "'";
            resultSet = statement.executeQuery(sql);
            if(resultSet.next()){
                JOptionPane.showMessageDialog(null, "Login Berhasil!!");
                dataMember.setWellcomeName(dataMember.getUser());
                new ViewUtama(dataMember);
            }
            else{
                JOptionPane.showMessageDialog(null, "Username atau Passworde Salah!!");
            }        
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            System.out.println("SQL exception error = " + ex);
            JOptionPane.showMessageDialog(null, "Username atau Passworde Salah!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
            System.out.println("Class Not Found Exception error = " + ex);
            
        }
    }
}
