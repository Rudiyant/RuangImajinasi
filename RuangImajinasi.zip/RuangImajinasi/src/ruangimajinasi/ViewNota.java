//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//View Nota

package ruangimajinasi;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class ViewNota extends JFrame {
    DatabasePesanan dbP = new DatabasePesanan();
    DataPesanan dataPesanan = new DataPesanan();
    DataMember dataMember = new DataMember();

    String DBurl = "jdbc:mysql://localhost/ruang_imajinasi";
    String DBuser = "root";
    String DBpass = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultSet;

    JLabel lnota, lruang, ltotalHarga, lbayar, lbg;
    JTextField fbayar;
    String[][] data = new String[20][2];
    String[] kolom = {"Pesanan", "Harga"};
    JTable tabel;
    JScrollPane scrollpane;
    JButton btnKembali;

    public ViewNota() {
        dbP.TotalHarga();
        dbP.CetakNota(data);

        setTitle("Nota Pembelian");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(300, 480);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);

        lruang = new JLabel();
        add(lruang).setBounds(30, 10, 405, 200);
        lruang.setIcon(new ImageIcon("src/Image/2.png"));

        lnota = new JLabel("Nota Pembelian");
        add(lnota).setBounds(80, 220, 140, 30);
        lnota.setFont(new Font("Gadugi", 1, 16));
        lnota.setForeground(Color.white);

        tabel = new JTable(data, kolom);
        scrollpane = new JScrollPane(tabel);
        add(scrollpane).setBounds(22, 260, 240, 100);
        scrollpane.setBackground(Color.black);
        scrollpane.setForeground(Color.white);
        tabel.setBackground(Color.black);
        tabel.setForeground(Color.white);

        ltotalHarga = new JLabel("Total Harga");
        add(ltotalHarga).setBounds(25, 370, 120, 20);
        ltotalHarga.setFont(new Font("Gadugi", 1, 12));
        ltotalHarga.setForeground(Color.white);

        lbayar = new JLabel("Rp ");
        add(lbayar).setBounds(110, 370, 120, 20);
        lbayar.setFont(new Font("Gadugi", 1, 12));
        lbayar.setForeground(Color.white);
        
        
        fbayar = new JTextField(30);
        String totalBayar = Integer.toString(dbP.bayar());
        fbayar.setText(" " + totalBayar);
        add(fbayar).setBounds(137, 370, 120, 20);
        fbayar.setFont(new Font("Gadugi", 1, 12));
        fbayar.setBackground(Color.black);
        fbayar.setForeground(Color.white);
        
        btnKembali = new JButton("Kembali Ke Menu");
        add(btnKembali).setBounds(60, 410, 150, 20);
        btnKembali.setBackground(Color.white);
        btnKembali.setForeground(Color.black);

        lbg = new JLabel();
        add(lbg).setBounds(0, 0, 300, 460);
        lbg.setIcon(new ImageIcon("src/Image/HITAM.jpg"));
        
        dbP.HapusDataPesanan();
        
        btnKembali.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUtama(dataMember);
                dispose();
            }
        });
    }

}
