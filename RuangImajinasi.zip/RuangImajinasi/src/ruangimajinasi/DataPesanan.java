//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//Class Model Pemesanan

package ruangimajinasi;

public class DataPesanan {
    String pesanan, harga, gelas, gula, catatan;
    int jumlah = 0;

    public String getPesanan() {
        return pesanan;
    }

    public void setPesanan(String pesanan) {
        this.pesanan = pesanan;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getGelas() {
        return gelas;
    }

    public void setGelas(String gelas) {
        this.gelas = gelas;
    }

    public String getGula() {
        return gula;
    }

    public void setGula(String gula) {
        this.gula = gula;
    }

    public String getCatatan() {
        return catatan;
    }

    public void setCatatan(String catatan) {
        this.catatan = catatan;
    }
    
    public void setTotalHagra(int totalHarga){
            jumlah = jumlah + totalHarga;
    }
    
    public int getTotalHarga()
    {
        return jumlah;
    }
}
