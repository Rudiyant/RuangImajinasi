//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//View Detail Buku

package ruangimajinasi;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ViewDetailBuku extends JFrame{
    DataMember dataMember = new DataMember();
    
    JLabel ljudul, ljudul2, lpenulis, lpenulis2, lpenerbit, lpenerbit2, ltahun, ltahun2, lkode, lkode2, lsinopsis, lgambar,
           lbg, ltitikdua1, ltitikdua2, ltitikdua3, ltitikdua4, ltitikdua5;
    JButton btnKembali;
    JTextArea lsinopsis2;
    JScrollPane scrollpane;
    
    public ViewDetailBuku(DataBuku dataBuku){
        
        setTitle("Detail Buku");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(470, 480);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        
        lgambar = new JLabel();
        add(lgambar).setBounds(20, 20, 100, 130);
        lgambar.setIcon(new ImageIcon(dataBuku.getGambar()));
        
        ljudul = new JLabel("Judul");
        add(ljudul).setBounds(135, 25, 80, 20);
        ljudul.setFont(new Font("Quicksand Light", 4, 16));
        ljudul.setForeground(Color.white);
        ltitikdua1 = new JLabel(":");
        add(ltitikdua1).setBounds(220, 25, 5, 20);
        ltitikdua1.setFont(new Font("Quicksand Light", 4, 16));
        ltitikdua1.setForeground(Color.white);
        ljudul2 = new JLabel(dataBuku.getJudul());
        add(ljudul2).setBounds(227, 25, 220, 20);
        ljudul2.setFont(new Font("Quicksand Light", 4, 16));
        ljudul2.setForeground(Color.white);
        
        lpenulis = new JLabel("Penulis");
        add(lpenulis).setBounds(135, 50, 80, 20);
        lpenulis.setFont(new Font("Quicksand Light", 4, 16));
        lpenulis.setForeground(Color.white);
        ltitikdua2 = new JLabel(":");
        add(ltitikdua2).setBounds(220, 50, 5, 20);
        ltitikdua2.setFont(new Font("Quicksand Light", 4, 16));
        ltitikdua2.setForeground(Color.white);
        lpenulis2 = new JLabel(dataBuku.getPenulis());
        add(lpenulis2).setBounds(227, 50, 200, 20);
        lpenulis2.setFont(new Font("Quicksand Light", 4, 16));
        lpenulis2.setForeground(Color.white);
        
        lpenerbit = new JLabel("Penerbit");
        add(lpenerbit).setBounds(135, 75, 80, 20);
        lpenerbit.setFont(new Font("Quicksand Light", 4, 16));
        lpenerbit.setForeground(Color.white);
        ltitikdua3 = new JLabel(":");
        add(ltitikdua3).setBounds(220, 75, 5, 20);
        ltitikdua3.setFont(new Font("Quicksand Light", 4, 16));
        ltitikdua3.setForeground(Color.white);
        lpenerbit2 = new JLabel(dataBuku.getPenerbit());
        add(lpenerbit2).setBounds(227, 75, 220, 20);
        lpenerbit2.setFont(new Font("Quicksand Light", 4, 16));
        lpenerbit2.setForeground(Color.white);
        
        ltahun = new JLabel("Tahun");
        add(ltahun).setBounds(135, 100, 80, 20);
        ltahun.setFont(new Font("Quicksand Light", 4, 16));
        ltahun.setForeground(Color.white);
        ltitikdua4 = new JLabel(":");
        add(ltitikdua4).setBounds(220, 100, 5, 20);
        ltitikdua4.setFont(new Font("Quicksand Light", 4, 16));
        ltitikdua4.setForeground(Color.white);
        ltahun2 = new JLabel(dataBuku.getTahun());
        add(ltahun2).setBounds(227, 100, 80, 20);
        ltahun2.setFont(new Font("Quicksand Light", 4, 16));
        ltahun2.setForeground(Color.white);
        
        lkode = new JLabel("Kode rak");
        add(lkode).setBounds(135, 125, 80, 20);
        lkode.setFont(new Font("Quicksand Light", 4, 16));
        lkode.setForeground(Color.white);
        ltitikdua5 = new JLabel(":");
        add(ltitikdua5).setBounds(220, 125, 5, 20);
        ltitikdua5.setFont(new Font("Quicksand Light", 4, 16));
        ltitikdua5.setForeground(Color.white);
        lkode2 = new JLabel(dataBuku.getKode());
        add(lkode2).setBounds(227, 125, 80, 20);
        lkode2.setFont(new Font("Quicksand Light", 4, 16));
        lkode2.setForeground(Color.white);
        
        lsinopsis = new JLabel("Sinopsis  : ");
        add(lsinopsis).setBounds(20, 160, 100, 20);
        lsinopsis.setFont(new Font("Quicksand Light", 4, 16));
        lsinopsis.setForeground(Color.white);
        lsinopsis2 = new JTextArea(200,300);
        add(lsinopsis2);
        lsinopsis2.setText(dataBuku.getSinopsis());
        lsinopsis2.setFont(new Font("Quicksand Light", 4, 16));
        lsinopsis2.setForeground(Color.white);
        lsinopsis2.setBackground(Color.black);
        scrollpane = new JScrollPane(lsinopsis2);
        add(scrollpane).setBounds(20, 190, 410, 180);
        scrollpane.setBackground(Color.black);
        scrollpane.setForeground(Color.white);

        
        btnKembali = new JButton("Kembali");
        add(btnKembali).setBounds(20, 400, 100, 20);
        btnKembali.setBackground(Color.white);
        btnKembali.setForeground(Color.black);
        
        lbg = new JLabel();
        add(lbg).setBounds(0, 0, 1000, 700);
        lbg.setIcon(new ImageIcon("src/Image/HITAM.jpg"));
        
        btnKembali.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewPerpus(dataMember);
                dispose();
            }
        });
    }
}
