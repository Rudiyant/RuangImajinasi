//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//View Perpustakaan

package ruangimajinasi;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ViewPerpus extends JFrame {
    DatabaseBuku dbB = new DatabaseBuku();
    
    JTextField fcari;
    JLabel lruang, lnama, lbg, ldaftarBuku, ljenisBuku1, ljenisBuku2;
    JLabel lnovel1, lnovel2, lnovel3, lnovel4, lnovel5, lnovel6, ljNovel1, ljNovel1b, ljNovel2, ljNovel2b, ljNovel3, ljNovel3b, ljNovel4, 
            ljNovel4b, ljNovel5, ljNovel5b, ljNovel6, ljNovel6b, lpNovel1, lpNovel2, lpNovel3, lpNovel4, lpNovel5, lpNovel6;
    JButton btnNovel1, btnNovel2, btnNovel3, btnNovel4, btnNovel5, btnNovel6;
    JPanel jgaris;
    JButton btnMenu, btnPerpus, btnLogout, btnCari;
    
    String judul, cari;

    public ViewPerpus(DataMember dataMember) {
        setTitle("Perpustakaan");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);

        lruang = new JLabel();
        add(lruang).setBounds(40, 0, 700, 150);
        lruang.setIcon(new ImageIcon("src/Image/1.png"));

        jgaris = new JPanel();
        add(jgaris).setBounds(40, 155, 900, 2);
        jgaris.setBackground(Color.white);

        btnLogout = new JButton("LogOut");
        add(btnLogout).setBounds(840, 70, 100, 20);
        btnLogout.setBackground(Color.white);
        btnLogout.setForeground(Color.black);

        lnama = new JLabel(dataMember.getWellcomeName());
        add(lnama).setBounds(770, 70, 120, 20);
        lnama.setFont(new Font("Gadugi", 1, 12));
        lnama.setForeground(Color.white);

        btnMenu = new JButton("Menu");
        add(btnMenu).setBounds(50, 185, 120, 20);
        btnMenu.setBackground(Color.white);
        btnMenu.setForeground(Color.black);

        btnPerpus = new JButton("Perpustakaan");
        add(btnPerpus).setBounds(210, 185, 120, 20);
        btnPerpus.setBackground(Color.white);
        btnPerpus.setForeground(Color.black);
        
        fcari = new JTextField(200);
        fcari.setText("Masukkan judul buku");
        add(fcari).setBounds(740, 185, 140, 20);
        fcari.setForeground(Color.white);
        fcari.setBackground(Color.black);
        btnCari = new JButton("Cari");
        add(btnCari).setBounds(880, 185, 60, 20);
        btnCari.setBackground(Color.white);
        btnCari.setForeground(Color.black);
        
        ldaftarBuku = new JLabel("Daftar Buku");
        add(ldaftarBuku).setBounds(60, 240, 300, 40);
        ldaftarBuku.setFont(new Font("Milasian Circa PERSONAL", 1, 40));
        ldaftarBuku.setForeground(Color.white);   
        
        ljenisBuku1 = new JLabel("Novel");
        add(ljenisBuku1).setBounds(60, 300, 300, 30);
        ljenisBuku1.setFont(new Font("Milasian Circa PERSONAL", 1, 30));
        ljenisBuku1.setForeground(Color.white);
        
        lnovel1 = new JLabel();
        add(lnovel1).setBounds(60, 345, 100, 130);
        lnovel1.setIcon(new ImageIcon("src/Image/KOLASE.jpg"));
        ljNovel1 = new JLabel("Konspirasi");
        add(ljNovel1).setBounds(180, 355, 200, 20);
        ljNovel1.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel1.setForeground(Color.white);
        ljNovel1b = new JLabel("Alam Semesta");
        add(ljNovel1b).setBounds(180, 380, 200, 20);
        ljNovel1b.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel1b.setForeground(Color.white);
        lpNovel1 = new JLabel("fiersa besari");
        add(lpNovel1).setBounds(180, 405, 200, 20);
        lpNovel1.setFont(new Font("Quicksand Light", 2, 14));
        lpNovel1.setForeground(Color.white);
        btnNovel1 = new JButton ("Detail");
        add(btnNovel1).setBounds(180, 445, 70, 15);
        btnNovel1.setBackground(Color.white);
        btnNovel1.setForeground(Color.black);
        
        lnovel2 = new JLabel();
        add(lnovel2).setBounds(60, 495, 100, 130);
        lnovel2.setIcon(new ImageIcon("src/Image/SEBUAH.jpg"));
        ljNovel2 = new JLabel("Sebuah Usaha");
        add(ljNovel2).setBounds(180, 505, 200, 20);
        ljNovel2.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel2.setForeground(Color.white);
        ljNovel2b = new JLabel("Melupakan");
        add(ljNovel2b).setBounds(180, 530, 200, 20);
        ljNovel2b.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel2b.setForeground(Color.white);
        lpNovel2 = new JLabel("boy candra");
        add(lpNovel2).setBounds(180, 555, 200, 20);
        lpNovel2.setFont(new Font("Quicksand Light", 2, 14));
        lpNovel2.setForeground(Color.white);
        btnNovel2 = new JButton ("Detail");
        add(btnNovel2).setBounds(180, 595, 70, 15);
        btnNovel2.setBackground(Color.white);
        btnNovel2.setForeground(Color.black);
        
        lnovel3 = new JLabel();
        add(lnovel3).setBounds(380, 345, 100, 130);
        lnovel3.setIcon(new ImageIcon("src/Image/CANTIK.jpg"));
        ljNovel3 = new JLabel("Cantik Itu");
        add(ljNovel3).setBounds(500, 355, 200, 20);
        ljNovel3.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel3.setForeground(Color.white);
        ljNovel3b = new JLabel("Luka");
        add(ljNovel3b).setBounds(500, 380, 200, 20);
        ljNovel3b.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel3b.setForeground(Color.white);
        lpNovel3 = new JLabel("eka kurniawan");
        add(lpNovel3).setBounds(500, 405, 200, 20);
        lpNovel3.setFont(new Font("Quicksand Light", 2, 14));
        lpNovel3.setForeground(Color.white);
        btnNovel3 = new JButton ("Detail");
        add(btnNovel3).setBounds(500, 445, 70, 15);
        btnNovel3.setBackground(Color.white);
        btnNovel3.setForeground(Color.black);
        
        lnovel4 = new JLabel();
        add(lnovel4).setBounds(380, 495, 100, 130);
        lnovel4.setIcon(new ImageIcon("src/Image/SEPOTONG.jpg"));
        ljNovel4 = new JLabel("Sepotong Hati");
        add(ljNovel4).setBounds(500, 505, 200, 20);
        ljNovel4.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel4.setForeground(Color.white);
        ljNovel4b = new JLabel("Yang Baru");
        add(ljNovel4b).setBounds(500, 530, 200, 20);
        ljNovel4b.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel4b.setForeground(Color.white);
        lpNovel4 = new JLabel("tere liye");
        add(lpNovel4).setBounds(500, 555, 200, 20);
        lpNovel4.setFont(new Font("Quicksand Light", 2, 14));
        lpNovel4.setForeground(Color.white);
        btnNovel4 = new JButton ("Detail");
        add(btnNovel4).setBounds(500, 595, 70, 15);
        btnNovel4.setBackground(Color.white);
        btnNovel4.setForeground(Color.black);
        
        lnovel5 = new JLabel();
        add(lnovel5).setBounds(695, 345, 100, 130);
        lnovel5.setIcon(new ImageIcon("src/Image/SARAPAN.jpg"));
        ljNovel5 = new JLabel("Sarapan Pagi");
        add(ljNovel5).setBounds(815, 355, 200, 20);
        ljNovel5.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel5.setForeground(Color.white);
        ljNovel5b = new JLabel("Penuh Dusta");
        add(ljNovel5b).setBounds(815, 380, 200, 20);
        ljNovel5b.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel5b.setForeground(Color.white);
        lpNovel5 = new JLabel("puthut ea");
        add(lpNovel5).setBounds(815, 405, 200, 20);
        lpNovel5.setFont(new Font("Quicksand Light", 2, 14));
        lpNovel5.setForeground(Color.white);
        btnNovel5 = new JButton ("Detail");
        add(btnNovel5).setBounds(815, 445, 70, 15);
        btnNovel5.setBackground(Color.white);
        btnNovel5.setForeground(Color.black);
        
        lnovel6 = new JLabel();
        add(lnovel6).setBounds(695, 495, 100, 130);
        lnovel6.setIcon(new ImageIcon("src/Image/FLOATING.jpg"));
        ljNovel6 = new JLabel("Floating");
        add(ljNovel6).setBounds(815, 505, 200, 20);
        ljNovel6.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel6.setForeground(Color.white);
        ljNovel6b = new JLabel("In Space");
        add(ljNovel6b).setBounds(815, 530, 200, 20);
        ljNovel6b.setFont(new Font("Quicksand Light", 1, 18));
        ljNovel6b.setForeground(Color.white);
        lpNovel6 = new JLabel("naela ali");
        add(lpNovel6).setBounds(815, 555, 200, 20);
        lpNovel6.setFont(new Font("Quicksand Light", 2, 14));
        lpNovel6.setForeground(Color.white);
        btnNovel6 = new JButton ("Detail");
        add(btnNovel6).setBounds(815, 595, 70, 15);
        btnNovel6.setBackground(Color.white);
        btnNovel6.setForeground(Color.black);

        lbg = new JLabel();
        add(lbg).setBounds(0, 0, 1000, 700);
        lbg.setIcon(new ImageIcon("src/Image/HITAM.jpg"));
        
        btnMenu.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUtama(dataMember);
                dispose();
            }
        });
        
        btnLogout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewLogin();
                dispose();
            }
        });
        
        btnNovel1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                judul = "Konspirasi Alam Semesta";
                dbB.DetailBuku(judul);
                dispose();
            }
        });
        
        btnNovel2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                judul = "Sebuah Usaha Melupakan";
                dbB.DetailBuku(judul);
                dispose();
            }
        });
        
        btnNovel3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                judul = "Cantik Itu Luka";
                dbB.DetailBuku(judul);
                dispose();
            }
        });
        
        btnNovel4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                judul = "Sepotong Hati Yang Baru";
                dbB.DetailBuku(judul);
                dispose();
            }
        });
        
        btnNovel5.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                judul = "Sarapan Pagi Penuh Dusta";
                dbB.DetailBuku(judul);
                dispose();
            }
        });
        
        btnNovel6.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                judul = "Floating In Space";
                dbB.DetailBuku(judul);
                dispose();
            }
        });
        
        btnCari.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                cari = fcari.getText();
                dbB.CariBuku(cari);
                dispose();
            }
        });
    }
}
