//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//View Login

package ruangimajinasi;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class ViewLogin extends JFrame{  
    JTextField fuser;
    JPasswordField fpass;
    JLabel luser, lpass, llogin, lruang, lbg;
    JButton btnSignup, btnLogin;
    
    DataMember dataMember = new DataMember();
    DatabaseMember dbM = new DatabaseMember();
    
    public ViewLogin() {
        setTitle("Login");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(300, 440);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);

        lruang = new JLabel();
        add(lruang).setBounds(30, 10, 405, 200);
        lruang.setIcon(new ImageIcon("src/Image/2.png"));

        llogin = new JLabel("Login Member");
        add(llogin).setBounds(100, 220, 120, 20);
        llogin.setFont(new Font("Gadugi", 1, 12));
        llogin.setForeground(Color.white);

        luser = new JLabel("Username");
        add(luser).setBounds(20, 255, 100, 20);
        luser.setFont(new Font("Gadugi", 1, 11));
        luser.setForeground(Color.white);

        fuser = new JTextField(10);
        add(fuser).setBounds(140, 255, 120, 20);
        fuser.setForeground(Color.white);

        lpass = new JLabel("Passworde");
        add(lpass).setBounds(20, 280,100, 20);
        lpass.setFont(new Font("Gadugi", 1, 11));
        lpass.setForeground(Color.white);

        fpass = new JPasswordField(10);
        add(fpass).setBounds(140, 280, 120, 20);
        fpass.setForeground(Color.white);
        
        btnLogin = new JButton("Login");
        add(btnLogin).setBounds(90, 320, 100, 20);
        btnLogin.setBackground(Color.white);
        btnLogin.setForeground(Color.black);
        
        btnSignup = new JButton("SignUp");
        add(btnSignup).setBounds(90, 360, 100, 20);
        btnSignup.setBackground(Color.white);
        btnSignup.setForeground(Color.black);

        fuser.setBackground(Color.black);
        fpass.setBackground(Color.black);
        
        lbg = new JLabel();
        add(lbg).setBounds(0, 0, 300, 440);
        lbg.setIcon(new ImageIcon("src/Image/HITAM.jpg"));

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String user, pass;
                user = fuser.getText();
                dataMember.setUser(user);
                pass = fpass.getText();
                dataMember.setPass(pass);
                dbM.LoginMember(dataMember);
            }
        });
        
        btnSignup.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewSignUp();
                dispose();
            }
        });
    }
}
