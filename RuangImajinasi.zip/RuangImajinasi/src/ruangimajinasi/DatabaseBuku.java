//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//Class COntroller Perpustakaan dan Buku

package ruangimajinasi;

import java.sql.*;
import javax.swing.*;

public class DatabaseBuku {

    DataBuku dataBuku = new DataBuku();
    DataMember dataMember = new DataMember();

    String DBurl = "jdbc:mysql://localhost/ruang_imajinasi";
    String DBuser = "root";
    String DBpass = "";
    Connection koneksi;
    Statement statement;
    ResultSet resultSet;

    public void DetailBuku(String judul) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            String sql = "SELECT * FROM `databuku` WHERE `judul`='" + judul + "'";
            resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                dataBuku.setGambar(resultSet.getString("gambar"));
                dataBuku.setJudul(resultSet.getString("judul"));
                dataBuku.setPenulis(resultSet.getString("penulis"));
                dataBuku.setPenerbit(resultSet.getString("penerbit"));
                dataBuku.setTahun(resultSet.getString("tahun"));
                dataBuku.setKode(resultSet.getString("kode"));
                dataBuku.setSinopsis(resultSet.getString("sinopsis"));
            }
            new ViewDetailBuku(dataBuku);
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            System.out.println("SQL exception error = " + ex);
            JOptionPane.showMessageDialog(null, "Username atau Passworde Salah!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
            System.out.println("Class Not Found Exception error = " + ex);

        }
    }

    public void CariBuku(String cari) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            koneksi = DriverManager.getConnection(DBurl, DBuser, DBpass);
            statement = koneksi.createStatement();
            String sql = "SELECT * FROM `databuku` WHERE `judul`='" + cari + "'";
            resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                dataBuku.setGambar(resultSet.getString("gambar"));
                dataBuku.setJudul(resultSet.getString("judul"));
                dataBuku.setPenulis(resultSet.getString("penulis"));
                dataBuku.setPenerbit(resultSet.getString("penerbit"));
                dataBuku.setTahun(resultSet.getString("tahun"));
                dataBuku.setKode(resultSet.getString("kode"));
                dataBuku.setSinopsis(resultSet.getString("sinopsis"));
                JOptionPane.showMessageDialog(null, "Buku Ditemukan!!");
                new ViewDetailBuku(dataBuku);
            } else {
                JOptionPane.showMessageDialog(null, "Buku Tidak Tersedia!!");
                new ViewPerpus(dataMember);
            }
            statement.close();
            koneksi.close();
        } catch (SQLException ex) {
            System.out.println("SQL exception error = " + ex);
            JOptionPane.showMessageDialog(null, "Username atau Passworde Salah!!");
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Driver tidak ditemukan!!");
            System.out.println("Class Not Found Exception error = " + ex);

        }
    }
}
