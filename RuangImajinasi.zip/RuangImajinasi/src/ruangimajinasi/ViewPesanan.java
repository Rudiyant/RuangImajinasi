//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//View Pesanan

package ruangimajinasi;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class ViewPesanan extends JFrame{
    DataMember dataMember = new DataMember();
    DatabasePesanan dbP = new DatabasePesanan();
    DataPesanan dataPesanan = new DataPesanan();
    
    String gelas, gula, catatan;
    
    JLabel lruang, lpesanan, lgelas, lgula, lcatatan, lbg;
    String[] tgelas =
            {"Kecil","Sedang","Besar"};
    String[] tgula = {"Ya", "Tidak"};
    JComboBox cmbGelas, cmbGula;
    JTextField fcatatan;
    JButton btnPesan, btnTambahPesanan, btnCetakNota;
    
    public ViewPesanan(String pesanan, String harga){
        setTitle("Pesan Menu");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(300, 540);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        
        lruang = new JLabel();
        add(lruang).setBounds(30, 10, 405, 200);
        lruang.setIcon(new ImageIcon("src/Image/2.png"));
        
        lpesanan = new JLabel(pesanan);
        add(lpesanan).setBounds(70, 215, 200, 40);
        lpesanan.setFont(new Font("Milasian Circa PERSONAL", 1, 30));
        lpesanan.setForeground(Color.white);
        
        lgelas = new JLabel("Ukuran Gelas");
        add(lgelas).setBounds(25, 275, 95, 20);
        lgelas.setFont(new Font("Gadugi", 1, 11));
        lgelas.setForeground(Color.white);

        cmbGelas = new JComboBox(tgelas);
        add(cmbGelas).setBounds(130, 275, 130, 20);
        cmbGelas.setForeground(Color.white);
        cmbGelas.setBackground(Color.black);
        
        lgula = new JLabel("Tambah Gula");
        add(lgula).setBounds(25, 310, 95, 20);
        lgula.setFont(new Font("Gadugi", 1, 11));
        lgula.setForeground(Color.white);

        cmbGula = new JComboBox(tgula);
        add(cmbGula).setBounds(130, 310, 130, 20);
        cmbGula.setForeground(Color.white);
        cmbGula.setBackground(Color.black);
        
        lcatatan = new JLabel("Catatan");
        add(lcatatan).setBounds(25, 345, 100, 20);
        lcatatan.setFont(new Font("Gadugi", 1, 11));
        lcatatan.setForeground(Color.white);

        fcatatan = new JTextField();
        add(fcatatan).setBounds(130, 345, 130, 20);
        fcatatan.setForeground(Color.white);
        fcatatan.setBackground(Color.black);
        
        btnPesan = new JButton("Pesan");
        add(btnPesan).setBounds(100, 390, 80, 20);
        btnPesan.setBackground(Color.white);
        btnPesan.setForeground(Color.black);
        
        btnTambahPesanan = new JButton("Tambah Pesanan");
        add(btnTambahPesanan).setBounds(70, 425, 140, 20);
        btnTambahPesanan.setBackground(Color.white);
        btnTambahPesanan.setForeground(Color.black);
        
        btnCetakNota = new JButton("Cetak Nota");
        add(btnCetakNota).setBounds(90, 460, 100, 20);
        btnCetakNota.setBackground(Color.white);
        btnCetakNota.setForeground(Color.black);
        
        lbg = new JLabel();
        add(lbg).setBounds(0, 0, 300, 540);
        lbg.setIcon(new ImageIcon("src/Image/HITAM.jpg"));
        
        btnPesan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dataPesanan.setPesanan(pesanan);
                dataPesanan.setHarga(harga);
                gelas = cmbGelas.getSelectedItem().toString();
                dataPesanan.setGelas(gelas);
                gula = cmbGula.getSelectedItem().toString();
                dataPesanan.setGula(gula);
                catatan = fcatatan.getText();
                dataPesanan.setCatatan(catatan);
                
                dbP.MasukDatabasePesanan(dataPesanan);
            }
        });
        
        btnTambahPesanan.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUtama(dataMember);
                dispose();
            }
        });
        
        btnCetakNota.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewNota();
                dispose();
            }
        });
    }
}
