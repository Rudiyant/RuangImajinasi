//Author : Rudiyanto
//2 Desember 2018
//Program Library and Coffee Shop
//Main Class

package ruangimajinasi;

public class RuangImajinasi {

    public static void main(String[] args) {
        new ViewLogin();
    }
}
